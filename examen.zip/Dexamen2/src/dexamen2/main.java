/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dexamen2;



/**
 *
 * @author antcha
 */
public class main {
    public static void main(String[] args) {
        examen2 ex2 = new examen2 ();
        ex2.setVisible(true);
                
    }
}
