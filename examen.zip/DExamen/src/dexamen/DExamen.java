/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dexamen;

/**
 *
 * @author antcha
 */
public class DExamen {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ejer1 j1 = new ejer1();
        j1.setVisible(true);
                
    }

   
    
}
